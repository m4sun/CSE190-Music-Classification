rm -r split-*
rm make_split.log
